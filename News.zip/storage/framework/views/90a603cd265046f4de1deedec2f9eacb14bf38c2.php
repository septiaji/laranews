  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <a class="navbar-brand" href="<?php if(auth()->guard()->check()): ?> /user <?php else: ?> / <?php endif; ?>">LaraNews</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <?php if(auth()->guard()->check()): ?>
          <li class="nav-item">
            <a class="nav-link" href="/user/post/create">Create Post</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/profile">Profile</a>
          </li>
          <li class="nav-item">
            <a
                class="nav-link"
                href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault(); document.getElementById('form-logout').submit()"
            >Logout</a>
            <form id="form-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
          </li>
        <?php else: ?>
          <li class="nav-item active">
            <a class="nav-link" href="/login">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/register">Register</a>
          </li>
        <?php endif; ?>
      </ul>
      <form action="<?php if(auth()->guard()->check()): ?> /user <?php else: ?> / <?php endif; ?>" method="GET" class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" name="search" value="<?php echo e(request()->get('search')); ?>" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
  </nav>
<?php /**PATH D:\Backup2\News\resources\views/components/navbar.blade.php ENDPATH**/ ?>