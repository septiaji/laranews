<?php $attributes = $attributes->exceptProps([
    'title'         => 'title',
    'subtitle'      => 'subtitle',
    'description'   => 'description',
]); ?>
<?php foreach (array_filter(([
    'title'         => 'title',
    'subtitle'      => 'subtitle',
    'description'   => 'description',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="jumbotron bg-dark text-white">
    <h1 class="display-4"><?php echo e($title); ?></h1>
    <p class="lead"><?php echo e($subtitle); ?></p>
    <hr class="my-4" />
    <p><?php echo e($description); ?></p>
</div>
<?php /**PATH D:\Backup2\News\resources\views/components/jumbotron.blade.php ENDPATH**/ ?>