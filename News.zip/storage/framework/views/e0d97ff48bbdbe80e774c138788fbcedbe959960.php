<div class="card bg-dark text-white mb-4">
    <div
        style="height: 36em; background-size: cover; background-image: url('<?php echo e(asset('images/' . $thumbnail)); ?>')"
    ></div>
    <div class="card-body">
        <h2 class="card-title"><?php echo e($title); ?></h2>
        <?php if($href !== ''): ?>
            <?php echo \Illuminate\Support\Str::limit(strip_tags($description), $limit = 200, $end = '.......'); ?>

        <?php else: ?>
            {<?php echo $description; ?>}
        <?php endif; ?>
        <p class="card-text">
            <p class="text-muted"><?php echo e($author); ?> - <?php echo e($publishedAt); ?></p>
        </p>

        <?php if($href !== ''): ?>
            <a href="<?php echo e($href); ?>" class="stretched-link"></a>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\Backup2\News\resources\views/components/post.blade.php ENDPATH**/ ?>