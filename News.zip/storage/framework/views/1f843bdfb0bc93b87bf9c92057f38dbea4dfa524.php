<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
             <?php if (isset($component)) { $__componentOriginal9f66b4056c9bdec37bc345101fc94ae9b9379070 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Post::class, ['title' => $post->title,'author' => $post->user->name,'thumbnail' => $post->thumbnail,'description' => $post->content,'publishedAt' => $post->created_at,'href' => '']); ?>
<?php $component->withName('post'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal9f66b4056c9bdec37bc345101fc94ae9b9379070)): ?>
<?php $component = $__componentOriginal9f66b4056c9bdec37bc345101fc94ae9b9379070; ?>
<?php unset($__componentOriginal9f66b4056c9bdec37bc345101fc94ae9b9379070); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Backup2\News\resources\views/home/post.blade.php ENDPATH**/ ?>