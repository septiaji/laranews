<?php echo e($slot); ?>

<?php /**PATH D:\Backup2\News\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>