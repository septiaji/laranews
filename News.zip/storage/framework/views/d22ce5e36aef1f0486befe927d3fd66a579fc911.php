<?php $__env->startSection('title'); ?>
    User - Create Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="card bg-dark text-white">
            <div class="card-body">
                <h2 class="card-title">Create Post</h2>
                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.post-form','data' => ['action' => route('user.post.update', ['post' => $post->id]),'title' => $post->title,'thumbnail' => $post->thumbnail,'content' => $post->content,'id' => $post->id]]); ?>
<?php $component->withName('post-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('user.post.update', ['post' => $post->id])),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post->title),'thumbnail' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post->thumbnail),'content' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post->content),'id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($post->id)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Backup2\News\resources\views/user/post-edit.blade.php ENDPATH**/ ?>